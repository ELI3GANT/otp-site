/**
 * OTP Site Configuration
 * Centralized credentials and settings.
 * Loaded before other scripts to ensure window.OTP_CONFIG is available.
 */
window.OTP_CONFIG = {
    supabaseUrl: 'https://ckumhowhucbbmpdeqkrl.supabase.co',
    supabaseKey: 'eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJpc3MiOiJzdXBhYmFzZSIsInJlZiI6ImNrdW1ob3dodWNiYm1wZGVxa3JsIiwicm9sZSI6ImFub24iLCJpYXQiOjE3Njc4NzQ3NjcsImV4cCI6MjA4MzQ1MDc2N30.yIJ1diGLWjtLWm8P2D5flF2nd0xPKn_8x2RR3DlIrag',
    apiBase: (function() {
        const h = window.location.hostname;
        if (h === 'localhost' || h === '127.0.0.1' || h.endsWith('.vercel.app')) return '';
        return 'https://otp-site.vercel.app';
    })(), // Empty string to force relative requests and avoid cross-origin/redirect issues
};

// Global Helper for resolving best API base
window.OTP = window.OTP || {};
window.OTP.getApiBase = function() {
    let base = window.OTP_CONFIG?.apiBase || '';
    if (window.location.hostname === 'localhost' || window.location.hostname === '127.0.0.1') {
        return window.location.origin;
    }
    return base;
};